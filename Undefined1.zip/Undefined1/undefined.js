const global = {
    superUser: [6635327336], // id mu, bisa lebih dari 1 id
    usernameOwner: "@AunuHost",
    botName: "Undercrasher_bot",
    botToken: "7048859328:AAHIyX-Y61dszHqKJ1CZEKRWMCaUQs306aY", // token bot mu
    channelLink: "https://t.me/TestiAunuHost",
    preview: 'https://g.top4top.io/m_3262j3ql81.mp4'
}

module.exports = global;